DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS Admin;
DROP TABLE IF EXISTS usr;
DROP TABLE IF EXISTS History;
DROP TABLE IF EXISTS ShoppingCart;



create table product(id int PRIMARY KEY IDENTITY,name varchar(30),price int,Quantity int,Company varchar(30),Category varchar(30));
INSERT INTO product
VALUES ('Sport Shoes', 70,4, 'Nike', 'Men');

INSERT INTO product
VALUES ('Flip-Flops', 20,2, 'Under Armour', 'Women');

INSERT INTO product
VALUES ('Sport Shoes', 30,7, 'Adidas', 'Kids');

INSERT INTO product
VALUES ('Flip-Flops', 19,10, 'Under Armour', 'Women');

INSERT INTO product
VALUES ('Loafer', 50,5, 'Aldo', 'Men');

INSERT INTO product
VALUES ('PartyShoes', 100,4, 'Aldo', 'Women');

INSERT INTO product
VALUES ('Sport Shoes', 112,8, 'Adidas', 'Men');

INSERT INTO product
VALUES ('Flip-Flops', 10.99,10, 'Nike', 'Kids');

INSERT INTO product
VALUES ('Flip-Flops', 29,10, 'Nike', 'Men');

INSERT INTO product
VALUES ('Loafer', 109.99,12, 'Adidas', 'Kids');

INSERT INTO product
VALUES ('PartyShoes', 120,87, 'Aldo', 'Men');

INSERT INTO product
VALUES ('Sport Shoes', 192,15, 'Under Armour', 'Women');

INSERT INTO product
VALUES ('Sport Shoes', 35.45,39, 'Under Armour', 'Kids');

INSERT INTO product
VALUES ('Sport Shoes', 60.99,5, 'Nike', 'Men');

INSERT INTO product
VALUES ('Loafer', 30.99,32, 'Aldo', 'Women');
INSERT INTO product
VALUES ('Flip-Flops', 89,3, 'Nike', 'Men');



create table Admin(Username varchar(20),User_password varchar(10),Admin_id int not null
primary key(admin_id)
);
insert into Admin values('mack', 'mac123',1);




create table usr(user_id int PRIMARY KEY IDENTITY,
username varchar(200),user_password varchar(100),Address varchar(300)
 );
INSERT INTO usr
VALUES ( 'Krutik','krutik', 'Brampton');

INSERT INTO usr
VALUES ( 'Akshar','akshar', 'Toronto');

INSERT INTO usr
VALUES ( 'Ujjaval','ujjaval', 'Mississauga');






create table History(user_id int,id int, name varchar(30),Quantity int,TotalPrice int,
);

create table ShoppingCart(user_id int,id int, name varchar(30),Quantity int,price int,
);

select * from Admin;
select * from usr;
select * from product;
select * from History;
select * from ShoppingCart;
