﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class user_shopping : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string product = DP1.Text;
                string company = DP2.Text;
                string category = DP3.Text;
                SqlConnection myConnection = new SqlConnection(myConnString);

                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("select * from product where name='" + product + "' OR Company ='" + company + "'  OR Category ='" + category + "'", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                GridView1.DataSource = myReader;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);

                string usr = Convert.ToString(Session["uid"]);
                string q = "select user_id from usr where username ='" + usr + "'";
                SqlCommand myCmd0 = new SqlCommand(q, myConnection);
                myConnection.Open();
                int uid = (int)myCmd0.ExecuteScalar();
                myConnection.Close();

                int id = int.Parse(TextBox1.Text);
                int quantity = int.Parse(TextBox2.Text);

                string q1 = "select name from product where id ='" + id + "'";
                SqlCommand myCmd = new SqlCommand(q1, myConnection);
                myConnection.Open();
                string name = (string)myCmd.ExecuteScalar();
                myConnection.Close();

                string q2 = "select price from product where id ='" + id + "'";
                SqlCommand myCmd1 = new SqlCommand(q2, myConnection);
                myConnection.Open();
                int price = (int)myCmd1.ExecuteScalar();
                myConnection.Close();

                string query = "insert into ShoppingCart values(@user_id,@id,@name,@Quantity,@price)";

                SqlCommand myCmd2 = new SqlCommand(query, myConnection);
                myCmd2.Parameters.AddWithValue("@user_id", uid);
                myCmd2.Parameters.AddWithValue("@id", id);
                myCmd2.Parameters.AddWithValue("@name", name);
                myCmd2.Parameters.AddWithValue("@Quantity", quantity);
                myCmd2.Parameters.AddWithValue("@price", price * quantity);
                myConnection.Open();
                myCmd2.ExecuteNonQuery();
                myConnection.Close();

                string query1 = "insert into History values(@user_id,@id,@name,@Quantity,@TotalPrice)";

                SqlCommand myCmd3 = new SqlCommand(query1, myConnection);
                myCmd3.Parameters.AddWithValue("@user_id", uid);
                myCmd3.Parameters.AddWithValue("@id", id);
                myCmd3.Parameters.AddWithValue("@name", name);
                myCmd3.Parameters.AddWithValue("@Quantity", quantity);
                myCmd3.Parameters.AddWithValue("@TotalPrice", price * 1.13 * quantity);
                myConnection.Open();
                myCmd3.ExecuteNonQuery();
                myConnection.Close();

                string q22 = "select Quantity from product where id ='" + id + "'";
                SqlCommand myCmd12 = new SqlCommand(q22, myConnection);
                myConnection.Open();
                int quan = (int)myCmd12.ExecuteScalar();
                myConnection.Close();

                int qua = quan - quantity;

                myConnection.Open();
                SqlCommand myCmd4 = new SqlCommand("update product set Quantity='" + qua + "' where id ='" + id + "'", myConnection);
                SqlDataReader myReader = myCmd4.ExecuteReader();
                myConnection.Close();

                Response.Redirect("~/ShoppingCart.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


        }
    }
}