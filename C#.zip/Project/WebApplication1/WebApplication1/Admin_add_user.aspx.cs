﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Admin_add_user : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Label4.Text = Convert.ToString(Session["userid"]);
                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                SqlCommand myCmd0 = new SqlCommand("select * from usr", myConnection);
                SqlDataReader myReader0 = myCmd0.ExecuteReader();
                GridView1.DataSource = myReader0;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                string uname = TextBox1.Text;
                string pass = TextBox2.Text;
                string add = TextBox3.Text;

                //if (!uname.Equals(null) && !pass.Equals(null) && !add.Equals(null))
                if (!String.IsNullOrEmpty(uname) && !String.IsNullOrEmpty(pass) && !String.IsNullOrEmpty(add))
                {
                    string qry1 = "insert into usr(username,user_password,Address) values('" + uname + "','" + pass + "','" + add + "')";
                    SqlCommand myCmd = new SqlCommand(qry1, myConnection);
                    SqlDataReader myReader = myCmd.ExecuteReader();
                    //  MessageBox.Show("<script>alert('Created User')</script>");
                    Response.Redirect("~/Admin.aspx");
                }
                else
                {
                    Response.Write("<script>alert('try again')</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}