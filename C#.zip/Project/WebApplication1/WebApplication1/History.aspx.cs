﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class History : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string username = Convert.ToString(Session["uid"]);
                Label1.Text = username;
                SqlConnection myConnection = new SqlConnection(myConnString);

                string q = "select user_id from usr where username ='" + username + "'";
                SqlCommand myCmd0 = new SqlCommand(q, myConnection);
                myConnection.Open();
                int uid = (int)myCmd0.ExecuteScalar();
                myConnection.Close();

                myConnection.Open();
                SqlCommand myCmd4 = new SqlCommand("select name,Quantity,TotalPrice from History where user_id ='" + uid + "'", myConnection);
                SqlDataReader myReader4 = myCmd4.ExecuteReader();
                GridView1.DataSource = myReader4;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/User.aspx");
        }
    }
}