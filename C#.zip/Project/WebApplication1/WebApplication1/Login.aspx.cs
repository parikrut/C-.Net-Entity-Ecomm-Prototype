﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Login : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        

            protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();

                string uid = TextBox3.Text;
                string pass = TextBox2.Text;
                string role = DropDownList1.Text;


                if (role == "Admin")
                {
                    string qry = "select * from Admin where username='" + uid + "' and user_password='" + pass + "'";

                    SqlCommand myCmd = new SqlCommand(qry, myConnection);
                    SqlDataReader myReader = myCmd.ExecuteReader();
                    if (myReader.Read())
                    {
                        Session["uid"] = uid.ToString();
                        Session["pass"] = uid.ToString();

                        Response.Redirect("~/Admin.aspx");

                    }
                    else
                    {
                        Label4.Text = "UserId & Password Is not correct Try again..!!";

                    }

                }
                else if (role == "User")
                {
                    string qry = "select * from usr where username='" + uid + "' and user_password='" + pass + "'";

                    SqlCommand myCmd1 = new SqlCommand(qry, myConnection);
                    SqlDataReader myReader1 = myCmd1.ExecuteReader();
                    if (myReader1.Read())
                    {
                        Session["uid"] = uid.ToString();
                        Response.Redirect("~/User.aspx");

                    }
                    else
                    {
                        Label4.Text = "UserId & Password Is not correct Try again..!!";

                    }

                }

                myConnection.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        

      

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("Register.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        
        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            this.TextBox2.Text = "";
        }
    }

   
    }
