﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class user_profile : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string username = Convert.ToString(Session["uid"]);
                Label1.Text = username;

                SqlConnection myConnection = new SqlConnection(myConnString);

                myConnection.Open();
                SqlCommand myCmd0 = new SqlCommand("select * from usr where username='" + username + "'", myConnection);
                SqlDataReader myReader0 = myCmd0.ExecuteReader();
                GridView1.DataSource = myReader0;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);

                string usr = Convert.ToString(Session["uid"]);
                string q = "select user_id from usr where username ='" + usr + "'";
                SqlCommand myCmd0 = new SqlCommand(q, myConnection);
                myConnection.Open();
                int uid = (int)myCmd0.ExecuteScalar();
                myConnection.Close();

                string username = TextBox1.Text;
                string pass = TextBox2.Text;
                string address = TextBox3.Text;

                if (!String.IsNullOrEmpty(username))
                {
                    myConnection.Open();
                    SqlCommand myCmd1 = new SqlCommand("update usr set username='" + username + "' where user_id='" + uid + "'", myConnection);
                    SqlDataReader myReader1 = myCmd1.ExecuteReader();
                    myConnection.Close();
                }
                if (!String.IsNullOrEmpty(pass))
                {
                    myConnection.Open();
                    SqlCommand myCmd2 = new SqlCommand("update usr set user_password='" + pass + "' where user_id='" + uid + "'", myConnection);
                    SqlDataReader myReader2 = myCmd2.ExecuteReader();
                    myConnection.Close();
                }
                if (!String.IsNullOrEmpty(address))
                {
                    myConnection.Open();
                    SqlCommand myCmd3 = new SqlCommand("update usr set Address='" + address + "' where user_id='" + uid + "'", myConnection);
                    SqlDataReader myReader3 = myCmd3.ExecuteReader();
                    myConnection.Close();
                }
                myConnection.Open();
                SqlCommand myCmd4 = new SqlCommand("select * from usr ", myConnection);
                SqlDataReader myReader4 = myCmd4.ExecuteReader();
                GridView1.DataSource = myReader4;
                GridView1.DataBind();
                myConnection.Close();
                Response.Write("<script>alert('Updated User')</script>");


                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/User.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}