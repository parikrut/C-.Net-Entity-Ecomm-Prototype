﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                string name = TextBox1.Text;
                string company = TextBox2.Text;
                string category = TextBox3.Text;
                string price = TextBox4.Text;
                string quntity = TextBox5.Text;

                if (!String.IsNullOrEmpty(name) && !String.IsNullOrEmpty(quntity) && !String.IsNullOrEmpty(company) && !String.IsNullOrEmpty(category) && !String.IsNullOrEmpty(price))
                {
                    string qry1 = "insert into product(name,price,Quantity,Company,Category) values('" + name + "','" + price + "','" + quntity + "','" + company + "','" + category + "')";
                    SqlCommand myCmd = new SqlCommand(qry1, myConnection);
                    SqlDataReader myReader = myCmd.ExecuteReader();
                    Response.Redirect("~/Admin_product.aspx");
                }
                else
                {
                    Response.Write("<script>alert('try again')</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Admin.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}