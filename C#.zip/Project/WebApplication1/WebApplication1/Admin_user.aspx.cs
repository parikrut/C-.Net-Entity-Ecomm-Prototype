﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class admin_manage_user : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Label3.Text = Convert.ToString(Session["uid"]);
                SqlConnection myConnection = new SqlConnection(myConnString);

                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("select * from usr", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                GridView1.DataSource = myReader;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);
                string uid = TextBox1.Text;
                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("delete from usr where user_id='" + uid + "'", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                GridView1.DataSource = myReader;
                GridView1.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            try
            {
                string uid = TextBox1.Text;
                Session["userid"] = uid.ToString();
                Response.Redirect("~/Admin_update_user.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Register.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Admin.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}