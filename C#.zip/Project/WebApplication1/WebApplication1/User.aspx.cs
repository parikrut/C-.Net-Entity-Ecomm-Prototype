﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class user_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Label1.Text = "Hi " + Convert.ToString(Session["uid"]);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("UserShopping.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("UserProfile.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            try
            {
                String username = Convert.ToString(Session["uid"]);
                String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(myConnString);

                myConnection.Open();
                SqlCommand myCmd4 = new SqlCommand("delete from usr where username ='" + username + "'", myConnection);
                SqlDataReader myReader4 = myCmd4.ExecuteReader();

                myConnection.Close();

                Response.Write("<script>alert('User Deleted')</script>");
                Response.Redirect("login.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("History.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}