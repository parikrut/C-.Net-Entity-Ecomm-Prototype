﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class admin_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Label1.Text = "Hi " + Convert.ToString(Session["uid"]);

                String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                SqlCommand myCmd0 = new SqlCommand("select * from usr", myConnection);
                SqlDataReader myReader0 = myCmd0.ExecuteReader();
                GridView1.DataSource = myReader0;
                GridView1.DataBind();
                myConnection.Close();
                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("select * from product", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                GridView2.DataSource = myReader;
                GridView2.DataBind();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Admin_user.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Admin_product.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}