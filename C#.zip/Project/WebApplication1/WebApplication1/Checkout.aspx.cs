﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Checkout : System.Web.UI.Page
    {
        String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);
                string usr = Convert.ToString(Session["uid"]);
                string q22 = "SELECT COUNT(*) FROM ShoppingCart";
                SqlCommand myCmd12 = new SqlCommand(q22, myConnection);
                myConnection.Open();
                int num = (int)myCmd12.ExecuteScalar();
                myConnection.Close();

                //   for (int i = 0; i < num; i++) {
                string q2 = "SELECT SUM(price) FROM ShoppingCart";
                SqlCommand myCmd2 = new SqlCommand(q2, myConnection);
                myConnection.Open();
                int Totalprice = (int)myCmd2.ExecuteScalar();
                myConnection.Close();


                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("select * from ShoppingCart", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                GridView1.DataSource = myReader;
                GridView1.DataBind();
                myConnection.Close();

                Label1.Text = usr;
                Label2.Text = Convert.ToString(Totalprice * 1.13);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                SqlCommand myCmd = new SqlCommand("Delete from ShoppingCart", myConnection);
                SqlDataReader myReader = myCmd.ExecuteReader();
                myConnection.Close();

                Response.Redirect("~/User.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}