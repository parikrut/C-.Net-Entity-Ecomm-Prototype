﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=shopping; Integrated Security=True";

                SqlConnection myConnection = new SqlConnection(myConnString);
                myConnection.Open();
                string uname = TextBox1.Text;
                string pass = TextBox2.Text;
                string add = TextBox3.Text;

                //if (!uname.Equals(null) && !pass.Equals(null) && !add.Equals(null))
                if (!String.IsNullOrEmpty(uname) && !String.IsNullOrEmpty(pass) && !String.IsNullOrEmpty(add))
                {
                    string qry1 = "insert into usr(username,user_password,Address) values('" + uname + "','" + pass + "','" + add + "')";
                    SqlCommand myCmd = new SqlCommand(qry1, myConnection);
                    SqlDataReader myReader = myCmd.ExecuteReader();
                    Response.Redirect("~/Login.aspx");
                }
                else
                {
                    Response.Write("<script>alert('try again')</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}